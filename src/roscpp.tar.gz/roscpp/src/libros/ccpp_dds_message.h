#ifndef CCPP_DDS_MESSAGE_H
#define CCPP_DDS_MESSAGE_H

#include "ccpp.h"
#include "ros/dds_message.h"
#include "ros/dds_messageDcps.h"
#include <orb_abstraction.h>
#include "ros/dds_messageDcps_impl.h"

#endif /* CCPP_DDS_MESSAGE_H */
