#ifndef CCPP_DDS_MESSAGE_H
#define CCPP_DDS_MESSAGE_H

#include "ccpp.h"
#include "dds_message.h"
#include "dds_messageDcps.h"
#include <orb_abstraction.h>
#include "dds_messageDcps_impl.h"

#endif /* CCPP_DDS_MESSAGE_H */
